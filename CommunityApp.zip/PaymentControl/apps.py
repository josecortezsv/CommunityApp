from django.apps import AppConfig


class PaymentcontrolConfig(AppConfig):
    name = 'PaymentControl'
